var sensor_veml7700_8h =
[
    [ "read_veml", "sensor-veml7700_8h.html#ab6bda9497b34d863e1e185b90870fc72", null ],
    [ "setup_veml", "sensor-veml7700_8h.html#a58a90a39871557ef6a62bd9f12cacfbe", null ]
];