var calc_8h =
[
    [ "calcRMS_float", "calc_8h.html#af6c64e9e1dab202a089a576d01eb4068", null ],
    [ "calcRMS_int", "calc_8h.html#a4d4e8264a870c170af44ae2fa3216cb8", null ],
    [ "calcRMSE_float", "calc_8h.html#a10a0440b4ccd27a29d3088a566ed0abd", null ],
    [ "calcRMSE_int", "calc_8h.html#ae2a8a6534973ed73e8a61f7d72bb119c", null ]
];