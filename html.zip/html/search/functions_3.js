var searchData=
[
  ['setup_5fscd41_0',['setup_scd41',['../sensor-scd41_8h.html#a3c18f7be4f868adeffebef51c2abfabe',1,'sensor-scd41.h']]],
  ['setup_5fveml_1',['setup_veml',['../sensor-veml7700_8h.html#a58a90a39871557ef6a62bd9f12cacfbe',1,'sensor-veml7700.h']]]
];
