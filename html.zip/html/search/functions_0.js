var searchData=
[
  ['calcrms_5ffloat_0',['calcRMS_float',['../calc_8h.html#af6c64e9e1dab202a089a576d01eb4068',1,'calc.h']]],
  ['calcrms_5fint_1',['calcRMS_int',['../calc_8h.html#a4d4e8264a870c170af44ae2fa3216cb8',1,'calc.h']]],
  ['calcrmse_5ffloat_2',['calcRMSE_float',['../calc_8h.html#a10a0440b4ccd27a29d3088a566ed0abd',1,'calc.h']]],
  ['calcrmse_5fint_3',['calcRMSE_int',['../calc_8h.html#ae2a8a6534973ed73e8a61f7d72bb119c',1,'calc.h']]]
];
