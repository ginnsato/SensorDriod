var searchData=
[
  ['printserialnumber_0',['printSerialNumber',['../sensor-scd41_8h.html#a2536801017b798b91f0afa4fa6e0e913',1,'sensor-scd41.h']]],
  ['printuint16hex_1',['printUint16Hex',['../sensor-scd41_8h.html#a5468e3a8aa9fcf290fe6155a72cdbe35',1,'sensor-scd41.h']]]
];
