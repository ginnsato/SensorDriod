var files_dup =
[
    [ "calc.h", "calc_8h.html", "calc_8h" ],
    [ "sensor-bme688.h", "sensor-bme688_8h.html", "sensor-bme688_8h" ],
    [ "sensor-bno055.h", "sensor-bno055_8h.html", "sensor-bno055_8h" ],
    [ "sensor-pmsa.h", "sensor-pmsa_8h.html", null ],
    [ "sensor-scd41.h", "sensor-scd41_8h.html", "sensor-scd41_8h" ],
    [ "sensor-veml7700.h", "sensor-veml7700_8h.html", "sensor-veml7700_8h" ]
];