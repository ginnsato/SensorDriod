var sensor_scd41_8h =
[
    [ "printSerialNumber", "sensor-scd41_8h.html#a2536801017b798b91f0afa4fa6e0e913", null ],
    [ "printUint16Hex", "sensor-scd41_8h.html#a5468e3a8aa9fcf290fe6155a72cdbe35", null ],
    [ "read_scd41", "sensor-scd41_8h.html#a71aa257fe013da4843961505dbf73af1", null ],
    [ "setup_scd41", "sensor-scd41_8h.html#a3c18f7be4f868adeffebef51c2abfabe", null ]
];